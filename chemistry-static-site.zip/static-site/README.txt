STATIC WEBSITE (HTML, CSS, XML, plus a little JavaScript for the chemistry tools)

Open index.html in a browser to see it. To publish, upload the whole folder to any static host.
1. Find every yellow [box] and replace it with your real details. Search the files for class="todo".
2. In sitemap.xml and robots.txt, replace example.com with your real web address.
3. Have a lawyer review privacy.html, terms.html and refunds.html, then delete their "Draft" line.
4. Confirm the licence terms of the element data (see js/elements.js) before publishing.
This site has no logins, payments or video lessons. Those need the full platform (chem-platform.zip).
