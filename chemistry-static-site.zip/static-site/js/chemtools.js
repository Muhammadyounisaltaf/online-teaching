/* Chemistry Tools: periodic table, equation balancing, molar mass. No libraries. All text is added with textContent, never as HTML. */
(function () {
  "use strict";
  var ELEMENTS = [], BY = {}, uidN = 0;
  var EQUATIONS = [
    { r: ["H2", "O2"], p: ["H2O"], a: [2, 1, 2] },
    { r: ["N2", "H2"], p: ["NH3"], a: [1, 3, 2] },
    { r: ["Fe", "O2"], p: ["Fe2O3"], a: [4, 3, 2] },
    { r: ["CH4", "O2"], p: ["CO2", "H2O"], a: [1, 2, 1, 2] },
    { r: ["Al", "HCl"], p: ["AlCl3", "H2"], a: [2, 6, 2, 3] },
    { r: ["C3H8", "O2"], p: ["CO2", "H2O"], a: [1, 5, 3, 4] },
    { r: ["Ca(OH)2", "H3PO4"], p: ["Ca3(PO4)2", "H2O"], a: [3, 2, 1, 6] },
    { r: ["Al2(SO4)3", "NaOH"], p: ["Al(OH)3", "Na2SO4"], a: [1, 6, 2, 3] },
    { r: ["C6H12O6", "O2"], p: ["CO2", "H2O"], a: [1, 6, 6, 6] }
  ];
  function setElements(list) { ELEMENTS = list; BY = {}; list.forEach(function (e) { BY[e.s] = e; }); }

  /* ---------- formula maths ---------- */
  function add(a, el, n) { a[el] = (a[el] || 0) + n; }
  function parseGroup(s) {
    var stack = [{}], i = 0;
    function num() { var j = i; while (j < s.length && s[j] >= "0" && s[j] <= "9") j++; var n = j > i ? Number(s.slice(i, j)) : 1; i = j; return n; }
    while (i < s.length) {
      var c = s[i];
      if (c === "(" || c === "[") { stack.push({}); i++; }
      else if (c === ")" || c === "]") {
        i++; var mult = num();
        if (stack.length < 2) return null;
        var top = stack.pop();
        Object.keys(top).forEach(function (k) { add(stack[stack.length - 1], k, top[k] * mult); });
      } else if (c >= "A" && c <= "Z") {
        var sym = c; i++;
        if (i < s.length && s[i] >= "a" && s[i] <= "z") { sym += s[i]; i++; }
        if (!BY[sym]) { if (sym.length === 2 && BY[c]) { i--; sym = c; } else return null; }
        var cnt = num();
        if (cnt < 1) return null;
        add(stack[stack.length - 1], sym, cnt);
      } else return null;
    }
    return stack.length === 1 && Object.keys(stack[0]).length ? stack[0] : null;
  }
  function parseFormula(input) {
    var parts = String(input).replace(/\((s|l|g|aq)\)/g, "").replace(/\s+/g, "").split(/[\u00B7.*]/), total = {};
    for (var k = 0; k < parts.length; k++) {
      var part = parts[k], mult = 1;
      if (k > 0) { var m = /^(\d+)(.*)$/.exec(part); if (m) { mult = Number(m[1]); part = m[2]; } }
      var atoms = parseGroup(part);
      if (!atoms) return null;
      (function (a, mu) { Object.keys(a).forEach(function (e) { add(total, e, a[e] * mu); }); })(atoms, mult);
    }
    return total;
  }
  function molarMass(a) { return Object.keys(a).reduce(function (s, e) { return s + a[e] * BY[e].mass; }, 0); }
  function totals(formulas, coefs) {
    var out = {};
    formulas.forEach(function (f, i) { var a = parseFormula(f) || {}; Object.keys(a).forEach(function (e) { add(out, e, a[e] * coefs[i]); }); });
    return out;
  }
  function gcd(a, b) { return b === 0 ? a : gcd(b, a % b); }

  /* ---------- small DOM helpers ---------- */
  function h(tag, props) {
    var e = document.createElement(tag);
    for (var k in props) {
      if (k === "class") e.className = props[k];
      else if (k === "text") e.textContent = props[k];
      else if (k.slice(0, 2) === "on") e.addEventListener(k.slice(2), props[k]);
      else e.setAttribute(k, props[k]);
    }
    for (var i = 2; i < arguments.length; i++) {
      var c = arguments[i];
      if (c === null || c === undefined || c === false) continue;
      e.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    }
    return e;
  }
  function uid() { uidN += 1; return "ct" + uidN; }
  function formula(f) { // digits after a letter or bracket become subscripts
    var frag = document.createDocumentFragment(), prev = "";
    for (var i = 0; i < f.length; i++) {
      if (/[0-9]/.test(f[i]) && /[A-Za-z)\]]/.test(prev)) {
        var j = i; while (j < f.length && /[0-9]/.test(f[j])) j++;
        frag.appendChild(h("sub", { text: f.slice(i, j) })); prev = f[j - 1]; i = j - 1;
      } else { frag.appendChild(document.createTextNode(f[i])); prev = f[i]; }
    }
    return frag;
  }

  /* ---------- periodic table ---------- */
  var HUE = { "alkali metal": 15, "alkaline earth metal": 40, "transition metal": 200, "post-transition metal": 170, "metalloid": 120,
    "diatomic nonmetal": 90, "polyatomic nonmetal": 65, "noble gas": 280, "lanthanide": 330, "actinide": 350, "unknown": 0 };
  function norm(c) { return c.indexOf("unknown") === 0 ? "unknown" : c; }
  function tint(node, cat) { node.style.setProperty("--h", HUE[norm(cat)]); node.style.setProperty("--sat", norm(cat) === "unknown" ? "0%" : "55%"); }

  function periodic(root) {
    var grid = h("div", { "class": "ct-ptable", role: "group", "aria-label": "Periodic table of the elements" });
    var detail = h("section", { "aria-live": "polite" }), buttons = {};
    function show(e) {
      Object.keys(buttons).forEach(function (n) { buttons[n].setAttribute("aria-pressed", String(Number(n) === e.n)); });
      var dl = h("dl", { "class": "ct-facts" });
      [["Atomic number", e.n], ["Atomic mass", e.mass], ["Group of elements", e.cat], ["State at standard conditions", e.phase],
        ["Electron configuration", e.config], ["Electronegativity (Pauling)", e.en === null ? "Not available" : e.en]].forEach(function (row) {
        dl.appendChild(h("dt", { text: row[0] })); dl.appendChild(h("dd", { text: String(row[1]) }));
      });
      detail.textContent = "";
      detail.appendChild(h("h3", { text: e.name + " (" + e.s + ")" })); detail.appendChild(dl);
    }
    ELEMENTS.forEach(function (e) {
      var b = h("button", { type: "button", "class": "ct-el", "aria-label": e.name + ", atomic number " + e.n, "aria-pressed": "false",
        onclick: function () { show(e); } }, h("small", { text: String(e.n) }), h("b", { text: e.s }));
      tint(b, e.cat); b.style.gridColumn = String(e.x); b.style.gridRow = String(e.y);
      buttons[e.n] = b; grid.appendChild(b);
    });
    var legend = h("ul", { "class": "ct-legend", "aria-label": "Colour key" });
    Object.keys(HUE).forEach(function (c) {
      var sw = h("i", { "aria-hidden": "true" }); tint(sw, c);
      legend.appendChild(h("li", {}, sw, c === "unknown" ? "properties not yet known" : c));
    });
    root.textContent = "";
    root.appendChild(h("div", { "class": "ct-ptable-wrap" }, grid)); root.appendChild(legend); root.appendChild(detail);
    root.appendChild(h("p", { "class": "ct-hint", text: "Atomic masses are rounded values and may differ slightly from your textbook. Element data: Periodic-Table-JSON by Bowserinator." }));
    show(ELEMENTS[0]);
  }

  /* ---------- equation balancing ---------- */
  function balance(root) {
    var idx = 0, area = h("div"), heading = h("p", { "class": "ct-status" });
    var prev = h("button", { type: "button", "class": "ct-btn", onclick: function () { idx--; build(); } }, "Previous equation");
    var next = h("button", { type: "button", "class": "ct-btn", onclick: function () { idx++; build(); } }, "Next equation");
    function build() {
      var eq = EQUATIONS[idx], species = eq.r.concat(eq.p), nR = eq.r.length;
      var n = species.map(function () { return 1; }), pre = [], val = [], minus = [], plus = [];
      var row = h("div", { "class": "ct-eq-row", role: "group", "aria-label": "Chemical equation" });
      var status = h("p", { "class": "ct-status", "aria-live": "polite" }), tally = h("ul", { "class": "ct-tally" });
      var box = h("div", { "class": "ct-eq" });
      function update() {
        var left = totals(eq.r, n.slice(0, nR)), right = totals(eq.p, n.slice(nR)), els = Object.keys(Object.assign({}, left, right));
        var ok = els.every(function (e) { return (left[e] || 0) === (right[e] || 0); }), simple = n.reduce(gcd) === 1;
        species.forEach(function (f, i) { pre[i].textContent = n[i] > 1 ? String(n[i]) : ""; val[i].textContent = String(n[i]); minus[i].disabled = n[i] === 1; plus[i].disabled = n[i] === 12; });
        box.className = "ct-eq" + (ok && simple ? " ct-ok" : "");
        status.textContent = ok ? (simple ? "Balanced, in the smallest whole numbers." : "Balanced, but all the numbers can be divided by a common factor.") : "Not balanced yet. Compare the atom counts below.";
        tally.textContent = "";
        els.forEach(function (e) { var l = left[e] || 0, r = right[e] || 0;
          tally.appendChild(h("li", { text: e + ": " + l + " atoms on the left, " + r + " on the right" + (l === r ? " (equal)" : "") })); });
      }
      species.forEach(function (f, i) {
        if (i > 0) row.appendChild(h("span", { "aria-hidden": "true", text: i === nR ? "\u2192" : "+" }));
        pre[i] = h("span"); val[i] = h("span", { "aria-hidden": "true" });
        minus[i] = h("button", { type: "button", "aria-label": "Decrease the coefficient of " + f, onclick: function () { n[i] = Math.max(1, n[i] - 1); update(); } }, "\u2212");
        plus[i] = h("button", { type: "button", "aria-label": "Increase the coefficient of " + f, onclick: function () { n[i] = Math.min(12, n[i] + 1); update(); } }, "+");
        row.appendChild(h("div", { "class": "ct-sp" }, h("span", {}, pre[i], formula(f)), h("div", { "class": "ct-step" }, minus[i], val[i], plus[i])));
      });
      box.appendChild(row); box.appendChild(status); box.appendChild(tally);
      box.appendChild(h("button", { type: "button", "class": "ct-btn ct-ghost", onclick: function () { n = eq.a.slice(); update(); } }, "Show the answer"));
      box.appendChild(document.createTextNode(" "));
      box.appendChild(h("button", { type: "button", "class": "ct-btn ct-ghost", onclick: function () { n = species.map(function () { return 1; }); update(); } }, "Start again"));
      area.textContent = ""; area.appendChild(box); update();
      heading.textContent = "Equation " + (idx + 1) + " of " + EQUATIONS.length;
      prev.disabled = idx === 0; next.disabled = idx === EQUATIONS.length - 1;
    }
    root.textContent = ""; root.appendChild(heading); root.appendChild(area);
    root.appendChild(h("p", {}, prev, " ", next)); build();
  }

  /* ---------- molar mass ---------- */
  function molar(root) {
    var id = uid();
    var input = h("input", { id: id + "f", value: "H2SO4", autocomplete: "off", spellcheck: "false" });
    var out = h("div", { "aria-live": "polite" });
    var mode = h("select", { id: id + "m" }, h("option", { value: "g", text: "the mass in grams" }), h("option", { value: "mol", text: "the amount in moles" }));
    var amount = h("input", { id: id + "a", inputmode: "decimal" }), amountLabel = h("label", { "for": id + "a", text: "Mass (g)" });
    var result = h("p", { "class": "ct-status", "aria-live": "polite" });
    var conv = h("div", {}, h("h3", { text: "Convert between grams and moles" }),
      h("div", { "class": "ct-field" }, h("label", { "for": id + "m", text: "I know" }), mode), h("div", { "class": "ct-field" }, amountLabel, amount), result);
    function refresh() {
      var f = input.value, atoms = f.trim() ? parseFormula(f) : null;
      out.textContent = ""; result.textContent = ""; conv.hidden = !atoms; amountLabel.textContent = mode.value === "g" ? "Mass (g)" : "Amount (mol)";
      if (f.trim() && !atoms) { out.appendChild(h("p", { "class": "ct-err", text: "That is not a valid formula. Check the capital and small letters: CO is carbon monoxide, but Co is cobalt." })); return; }
      if (!atoms) return;
      var M = molarMass(atoms);
      out.appendChild(h("p", { "class": "ct-status" }, formula(f.replace(/\s+/g, "")), " has a molar mass of " + M.toFixed(2) + " g/mol."));
      var body = h("tbody");
      Object.keys(atoms).forEach(function (e) { var sub = atoms[e] * BY[e].mass;
        var tr = h("tr"); [BY[e].name + " (" + e + ")", atoms[e], BY[e].mass.toFixed(3), sub.toFixed(3), (sub / M * 100).toFixed(2) + "%"].forEach(function (v) { tr.appendChild(h("td", { text: String(v) })); });
        body.appendChild(tr); });
      var head = h("tr"); ["Element", "Atoms", "Atomic mass", "Mass in the formula", "Percent by mass"].forEach(function (t) { head.appendChild(h("th", { scope: "col", text: t })); });
      out.appendChild(h("div", { "class": "ct-scroll" }, h("table", { "class": "ct-table" }, h("caption", { text: "Mass of each element in one mole" }), h("thead", {}, head), body)));
      var x = Number(amount.value);
      if (amount.value.trim() !== "" && isFinite(x) && x >= 0) { var v = mode.value === "g" ? x / M : x * M; result.textContent = Number(v.toPrecision(4)) + (mode.value === "g" ? " mol" : " g"); }
    }
    [input, amount].forEach(function (e) { e.addEventListener("input", refresh); }); mode.addEventListener("change", refresh);
    root.textContent = "";
    root.appendChild(h("div", { "class": "ct-field" }, h("label", { "for": id + "f", text: "Chemical formula" }), input,
      h("p", { "class": "ct-hint", text: "Examples: H2O, Ca(OH)2, Al2(SO4)3, CuSO4.5H2O. Capital and small letters matter." })));
    root.appendChild(out); root.appendChild(conv);
    root.appendChild(h("p", { "class": "ct-hint", text: "These answers use precise atomic masses. Your exam may use rounded values such as H = 1 and O = 16, so check your board's syllabus." }));
    refresh();
  }

  var TOOLS = { periodic: periodic, balance: balance, molar: molar };
  function init() {
    var roots = document.querySelectorAll(".chemtools");
    if (!roots.length) return;
    if (window.CHEMTOOLS_ELEMENTS) { setElements(window.CHEMTOOLS_ELEMENTS); Array.prototype.forEach.call(roots, function (r) { var t = TOOLS[r.getAttribute("data-tool")]; if (t) t(r); }); return; }
    fetch(window.ChemToolsConfig.elementsUrl).then(function (r) { if (!r.ok) throw new Error("load"); return r.json(); }).then(function (list) {
      setElements(list);
      Array.prototype.forEach.call(roots, function (r) { var t = TOOLS[r.getAttribute("data-tool")]; if (t) t(r); });
    }).catch(function () { Array.prototype.forEach.call(roots, function (r) { r.textContent = "The chemistry tool could not load. Please refresh the page."; }); });
  }
  if (typeof document !== "undefined") { if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init(); }
  if (typeof module !== "undefined" && module.exports) module.exports = { parseFormula: parseFormula, molarMass: molarMass, totals: totals, gcd: gcd, setElements: setElements, EQUATIONS: EQUATIONS };
})();
